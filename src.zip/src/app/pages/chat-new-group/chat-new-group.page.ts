import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chat-new-group',
  templateUrl: './chat-new-group.page.html',
  styleUrls: ['./chat-new-group.page.scss'],
})
export class ChatNewGroupPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
