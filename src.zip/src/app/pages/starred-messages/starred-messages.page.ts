import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-starred-messages',
  templateUrl: './starred-messages.page.html',
  styleUrls: ['./starred-messages.page.scss'],
})
export class StarredMessagesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
