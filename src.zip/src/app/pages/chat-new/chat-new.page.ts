import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chat-new',
  templateUrl: './chat-new.page.html',
  styleUrls: ['./chat-new.page.scss'],
})
export class ChatNewPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
