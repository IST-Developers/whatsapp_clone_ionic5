import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-status-privacy',
  templateUrl: './status-privacy.page.html',
  styleUrls: ['./status-privacy.page.scss'],
})
export class StatusPrivacyPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
