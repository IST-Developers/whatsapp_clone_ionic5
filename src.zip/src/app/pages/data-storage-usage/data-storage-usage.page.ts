import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-storage-usage',
  templateUrl: './data-storage-usage.page.html',
  styleUrls: ['./data-storage-usage.page.scss'],
})
export class DataStorageUsagePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
