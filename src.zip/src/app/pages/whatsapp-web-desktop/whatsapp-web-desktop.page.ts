import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-whatsapp-web-desktop',
  templateUrl: './whatsapp-web-desktop.page.html',
  styleUrls: ['./whatsapp-web-desktop.page.scss'],
})
export class WhatsappWebDesktopPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
